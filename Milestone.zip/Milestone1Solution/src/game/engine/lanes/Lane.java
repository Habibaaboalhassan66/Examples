package game.engine.lanes;

import java.util.ArrayList;

import java.util.PriorityQueue;
import game.engine.base.Wall;
import game.engine.titans.Titan;
import game.engine.weapons.Weapon;

public class Lane implements Comparable<Lane> {
	private final Wall laneWall;
	private int dangerLevel;
	private final PriorityQueue<Titan> titans;
	private final ArrayList<Weapon> weapons;

	public Lane(Wall laneWall) {
		super();
		this.laneWall = laneWall;
		this.dangerLevel = 0;
		this.titans = new PriorityQueue<>();
		this.weapons = new ArrayList<>();
	}

	public Wall getLaneWall() {
		return this.laneWall;
	}

	public int getDangerLevel() {
		return this.dangerLevel;
	}

	public void setDangerLevel(int dangerLevel) {
		this.dangerLevel = dangerLevel;
	}

	public PriorityQueue<Titan> getTitans() {
		return this.titans;
	}

	public ArrayList<Weapon> getWeapons() {
		return this.weapons;
	}

	@Override
	public int compareTo(Lane o) {
		return this.dangerLevel - o.dangerLevel;
	}

	public void addTitan(Titan titan) {
		titans.add(titan);
	}

	public void addWeapon(Weapon weapon) {
		weapons.add(weapon);
	}

	public void moveLaneTitans() {
		PriorityQueue<Titan> TempTitans = new PriorityQueue<Titan>();
		while (!titans.isEmpty()) {
			Titan x = titans.poll();
			if (!x.hasReachedTarget()) {
				x.move();
				TempTitans.add(x);
			}
			else
				TempTitans.add(x);

		}
		titans.addAll(TempTitans);

	}

	public int performLaneTitansAttacks() {
		PriorityQueue<Titan> TempTitans = new PriorityQueue<Titan>();
		int ResourcesGathered = 0;
		while (!titans.isEmpty()) {
			Titan x = titans.poll();
			if (x.getDistance() == 0) {
				ResourcesGathered = x.attack(laneWall);
				TempTitans.add(x);
			}
		}
		titans.addAll(TempTitans);
		return ResourcesGathered;
	}

	public int performLaneWeaponsAttacks() {
		int ResourcesGathered = 0;
		for (int i = 0; i < weapons.size(); i++) {
			ResourcesGathered = (weapons.get(i)).turnAttack(titans);
		}
		return ResourcesGathered;
	}

	public boolean isLaneLost() {
		return laneWall.isDefeated();
	}

	public void updateLaneDangerLevel() {
		PriorityQueue<Titan> TempTitans = new PriorityQueue<Titan>();
		int DangerLevel = 0;
		while (!titans.isEmpty()) {
			Titan x = titans.poll();
			DangerLevel += x.getDangerLevel();
			TempTitans.add(x);
		}
		titans.addAll(TempTitans);
		setDangerLevel(DangerLevel);
	}

}
