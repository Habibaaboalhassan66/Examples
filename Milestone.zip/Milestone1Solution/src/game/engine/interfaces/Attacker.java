package game.engine.interfaces;

public interface Attacker
{
	int getDamage(); // gets the damage value to be applied
	
	default public int attack(Attackee target){
//		target.setCurrentHealth(target.getCurrentHealth()-getDamage());
//		if(target.isDefeated()==true)
//			return target.getResourcesValue();
//		else
//			return 0;
		return target.takeDamage(getDamage());
	}
}
