package game.engine;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.PriorityQueue;

import game.engine.base.Wall;
import game.engine.dataloader.DataLoader;
import game.engine.exceptions.InsufficientResourcesException;
import game.engine.exceptions.InvalidLaneException;
import game.engine.lanes.Lane;
import game.engine.titans.PureTitan;
import game.engine.titans.Titan;
import game.engine.titans.TitanRegistry;
import game.engine.weapons.WeaponRegistry;
import game.engine.weapons.factory.FactoryResponse;
import game.engine.weapons.factory.WeaponFactory;

public class Battle
{
	private static final int[][] PHASES_APPROACHING_TITANS =
	{
		{ 1, 1, 1, 2, 1, 3, 4 },
		{ 2, 2, 2, 1, 3, 3, 4 },
		{ 4, 4, 4, 4, 4, 4, 4 } 
	}; // order of the types of titans (codes) during each phase
	private static final int WALL_BASE_HEALTH = 10000;

	private int numberOfTurns;
	private int resourcesGathered;
	private BattlePhase battlePhase;
	private int numberOfTitansPerTurn; // initially equals to 1
	private int score; // Number of Enemies Killed
	private int titanSpawnDistance;
	private final WeaponFactory weaponFactory;
	private final HashMap<Integer, TitanRegistry> titansArchives;
	private final ArrayList<Titan> approachingTitans; // treated as a Queue
	private final PriorityQueue<Lane> lanes;
	private final ArrayList<Lane> originalLanes;

	public Battle(int numberOfTurns, int score, int titanSpawnDistance, int initialNumOfLanes,
			int initialResourcesPerLane) throws IOException
	{
		super();
		this.numberOfTurns = numberOfTurns;
		this.battlePhase = BattlePhase.EARLY;
		this.numberOfTitansPerTurn = 1;
		this.score = score;
		this.titanSpawnDistance = titanSpawnDistance;
		this.resourcesGathered = initialResourcesPerLane * initialNumOfLanes;
		this.weaponFactory = new WeaponFactory();
		this.titansArchives = DataLoader.readTitanRegistry();
		this.approachingTitans = new ArrayList<Titan>();
		this.lanes = new PriorityQueue<>();
		this.originalLanes = new ArrayList<>();
		this.initializeLanes(initialNumOfLanes);
	}

	public int getNumberOfTurns()
	{
		return numberOfTurns;
	}

	public void setNumberOfTurns(int numberOfTurns)
	{
		this.numberOfTurns = numberOfTurns;
	}

	public int getResourcesGathered()
	{
		return resourcesGathered;
	}

	public void setResourcesGathered(int resourcesGathered)
	{
		this.resourcesGathered = resourcesGathered;
	}

	public BattlePhase getBattlePhase()
	{
		return battlePhase;
	}

	public void setBattlePhase(BattlePhase battlePhase)
	{
		this.battlePhase = battlePhase;
	}

	public int getNumberOfTitansPerTurn()
	{
		return numberOfTitansPerTurn;
	}

	public void setNumberOfTitansPerTurn(int numberOfTitansPerTurn)
	{
		this.numberOfTitansPerTurn = numberOfTitansPerTurn;
	}

	public int getScore()
	{
		return score;
	}

	public void setScore(int score)
	{
		this.score = score;
	}

	public int getTitanSpawnDistance()
	{
		return titanSpawnDistance;
	}

	public void setTitanSpawnDistance(int titanSpawnDistance)
	{
		this.titanSpawnDistance = titanSpawnDistance;
	}

	public WeaponFactory getWeaponFactory()
	{
		return weaponFactory;
	}

	public HashMap<Integer, TitanRegistry> getTitansArchives()
	{
		return titansArchives;
	}

	public ArrayList<Titan> getApproachingTitans()
	{
		return approachingTitans;
	}

	public PriorityQueue<Lane> getLanes()
	{
		return lanes;
	}

	public ArrayList<Lane> getOriginalLanes()
	{
		return originalLanes;
	}

	private void initializeLanes(int numOfLanes)
	{
		for (int i = 0; i < numOfLanes; i++)
		{
			Wall w = new Wall(WALL_BASE_HEALTH);
			Lane l = new Lane(w);

			this.getOriginalLanes().add(l);
			this.getLanes().add(l);
		}
	}
	public void refillApproachingTitans(){
		int TitansCode[]  = new int[7] ;
		
		switch(battlePhase){
			case EARLY:
				int[] x = PHASES_APPROACHING_TITANS[0];
				for(int i=0;i<x.length;i++){
					TitansCode[i]=x[i];
				}
				break;
				
			case INTENSE:
				int[] z = PHASES_APPROACHING_TITANS[1];
				for(int i=0;i<z.length;i++){
					TitansCode[i]=z[i];
				}
				break;
				
			case GRUMBLING:
				int[] w = PHASES_APPROACHING_TITANS[2];
				for(int i=0;i<w.length;i++){
					TitansCode[i]=w[i];
				}
				break;
				
			default:
				break;
		}
		
		for(int i=0;i<TitansCode.length;i++){
			TitanRegistry y=titansArchives.get(TitansCode[i]);
			if (y != null) {
	            Titan z = y.spawnTitan(titanSpawnDistance);
	            approachingTitans.add(z);
	        }
	        
		}
	}
		
	
	
	 public void purchaseWeapon(int weaponCode, Lane lane) throws InsufficientResourcesException,InvalidLaneException{
				if(!lanes.contains(lane)){
			throw new InvalidLaneException();
		}
				else{
		
					FactoryResponse x= weaponFactory.buyWeapon(weaponCode,getResourcesGathered());
					lane.addWeapon(x.getWeapon());
					setResourcesGathered(x.getRemainingResources());
				}
				performTurn();
	}
	 
	private void passTurn(){
		performTurn();
		
	}
		
	private void addTurnTitansToLane(){
		
		Lane l =lanes.poll();
		for(int i=0;i<numberOfTitansPerTurn;i++){
			if(approachingTitans.isEmpty()){
				refillApproachingTitans();
			}
			l.addTitan(approachingTitans.get(0));
			approachingTitans.remove(0);
		}
		lanes.add(l);
	}
		
		 private void moveTitans(){
			 ArrayList<Lane>x=new ArrayList<>();
			 while(!lanes.isEmpty()){
				 Lane l=lanes.poll();
				 l.moveLaneTitans();
				 x.add(l);
			 }
			 lanes.addAll(x);
		 }
		 private int performWeaponsAttacks(){
			 PriorityQueue temp = new PriorityQueue<>();
			 int x=0;
			 while (!lanes.isEmpty()){
				 Lane l=lanes.poll();
				 x=x+ l.performLaneWeaponsAttacks();
				 temp.add(l);
			 }
			 lanes.addAll(temp);
			 return x;
		 }
		 private int performTitansAttacks(){
			 ArrayList t =new ArrayList<>();
			 int x=0;
			 while(!lanes.isEmpty()){
				 Lane y=lanes.poll();
				 x=+y.performLaneTitansAttacks();
				 t.add(y);
			 }
			 originalLanes.addAll(t);
			 return x;
		 }
		 
		 private void updateLanesDangerLevels(){
			 ArrayList<Lane> temp = new ArrayList<Lane>();
			 
			 while (!lanes.isEmpty()){
				 Lane l= lanes.poll();
				 l.updateLaneDangerLevel();
				 temp.add(l);
			 }
			 lanes.addAll(temp);
		 }
		 
		 private void finalizeTurns(){
			 setNumberOfTurns(getNumberOfTurns()+1);
			 if(getNumberOfTurns()<15)
				 setBattlePhase(BattlePhase.EARLY);
			 else{
				 if(getNumberOfTurns()<30)
					 setBattlePhase(BattlePhase.INTENSE);
				 else{
					 if(getNumberOfTurns()>=30 )
						 setBattlePhase(BattlePhase.GRUMBLING);
					 if(getNumberOfTurns()>30 && getNumberOfTurns()%5==0){
						 setNumberOfTitansPerTurn(getNumberOfTitansPerTurn()*2);
					 }
			 }
			
		 }
		 }
		 
		 private void performTurn(){
			 moveTitans();
			 performWeaponsAttacks();
			 performTitansAttacks();
			 addTurnTitansToLane();
			 updateLanesDangerLevels();
			 finalizeTurns();
		 }
		 
		 boolean isGameOver(){
			 if(lanes.isEmpty())
				 return true;
			 else
				 return false;
		 }
		 
}

	
	


	