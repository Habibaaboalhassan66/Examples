package game.engine.weapons;

import game.engine.titans.Titan;

import java.util.PriorityQueue;

public class WallTrap extends Weapon
{
	public static final int WEAPON_CODE = 4;

	public WallTrap(int baseDamage)
	{
		super(baseDamage);
	}

	@Override
	public int turnAttack(PriorityQueue<Titan> laneTitans) {
		int ResourcesGathered=0;
		PriorityQueue<Titan> TempTitans = new PriorityQueue<>();
//		while(!laneTitans.isEmpty()){
			Titan x = laneTitans.poll();
			int distance= x.getDistance();
			if(distance==0){
				x.setCurrentHealth(x.getCurrentHealth()-getDamage());
				if(x.isDefeated()){
					ResourcesGathered=ResourcesGathered+x.getResourcesValue();
				}
				if(!x.isDefeated())	
					laneTitans.add(x);
				}
//			}
			

		return ResourcesGathered;
}
}