package game.engine.weapons;

import game.engine.titans.Titan;

import java.util.PriorityQueue;

public class SniperCannon extends Weapon
{
	public static final int WEAPON_CODE = 2;

	public SniperCannon(int baseDamage)
	{
		super(baseDamage);
	}
	
	public int turnAttack(PriorityQueue<Titan> laneTitans){
		int resourcesGained=0;
		if(!laneTitans.isEmpty()){
			Titan x=laneTitans.poll();
			if(x!=null){
				resourcesGained= attack(x);
			}
//			x.setCurrentHealth(x.getCurrentHealth()-getDamage());
			if(x.isDefeated()==false){
				laneTitans.add(x);
			}
			
		}
		return resourcesGained;
	}

}
