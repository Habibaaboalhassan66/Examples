package game.engine.weapons;

import game.engine.titans.Titan;

import java.util.PriorityQueue;

public class PiercingCannon extends Weapon
{
	public static final int WEAPON_CODE = 1;

	public PiercingCannon(int baseDamage)
	{
		super(baseDamage);
	}

	public int turnAttack(PriorityQueue<Titan> laneTitans)
	{
		int count=0;
		int resourcesGained=0;
		PriorityQueue<Titan> TempLaneTitans = new PriorityQueue<Titan>() ;
	
		while(!laneTitans.isEmpty() && count<5)
		{
			Titan x=laneTitans.poll();
			if(x!=null){
				resourcesGained += attack(x);
			}
		
			if(x.isDefeated()==false){
				TempLaneTitans.add(x);
			}
			count++;	
		}
		while(!TempLaneTitans.isEmpty())
		{
			laneTitans.add(TempLaneTitans.poll());
		}
		return resourcesGained;
	}

	private int getresourcesValue() {
		// TODO Auto-generated method stub
		return 0;
	} 

}	
